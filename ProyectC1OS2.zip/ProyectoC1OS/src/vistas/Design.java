package vistas;

import java.awt.Color;
import java.awt.Font;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import javax.swing.table.JTableHeader;
import control.Proceso;
import control.Cola;
import javax.swing.table.DefaultTableModel;

public class Design extends javax.swing.JFrame implements Runnable {

    String hour, minuts, seconds, turno;
    Calendar calendar;
    Thread hilo;
    int quantum;

    public Design() {
        initComponents();
        initComponents2();

        hilo = new Thread(this);
        hilo.start();

        setVisible(true);
        setLocationRelativeTo(null);
        this.getContentPane().setBackground(Color.DARK_GRAY);
    }

    public void calculateHour() {
        Calendar calendario = new GregorianCalendar();
        Date fechaHoraActual = new Date();

        calendario.setTime(fechaHoraActual);
        turno = calendario.get(Calendar.AM_PM) == Calendar.AM ? "a.m" : "p.m";

        if (turno.equals("p.m")) {
            int h = calendario.get(Calendar.HOUR_OF_DAY) - 12;
            hour = h > 9 ? "" + h : "0" + h;
        } else {
            hour = calendario.get(Calendar.HOUR_OF_DAY) > 9 ? "" + calendario.get(Calendar.HOUR_OF_DAY) : "0" + calendario.get(Calendar.HOUR_OF_DAY);
        }

        minuts = calendario.get(Calendar.MINUTE) > 9 ? "" + calendario.get(Calendar.MINUTE) : "0" + calendario.get(Calendar.MINUTE);
        seconds = calendario.get(Calendar.SECOND) > 9 ? "" + calendario.get(Calendar.SECOND) : "0" + calendario.get(Calendar.SECOND);
    }

    @SuppressWarnings("unchecked")

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel5 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        labelHour = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        Empezar = new javax.swing.JButton();

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Simulacion Sistema Operativo");
        setBackground(new java.awt.Color(51, 51, 51));
        setForeground(new java.awt.Color(51, 51, 51));
        setSize(new java.awt.Dimension(1500, 800));
        getContentPane().setLayout(null);

        jPanel6.setBackground(new java.awt.Color(0, 0, 0));

        labelHour.setBackground(new java.awt.Color(0, 0, 0));
        labelHour.setFont(new java.awt.Font("Dialog", 1, 26)); // NOI18N
        labelHour.setForeground(new java.awt.Color(255, 255, 255));
        labelHour.setText("          ");
        labelHour.setMaximumSize(new java.awt.Dimension(300, 32));
        labelHour.setMinimumSize(new java.awt.Dimension(300, 32));
        labelHour.setPreferredSize(new java.awt.Dimension(300, 32));

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addComponent(labelHour, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(labelHour, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel6);
        jPanel6.setBounds(590, 360, 170, 40);

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(0, 0, 0), new java.awt.Color(0, 0, 0), new java.awt.Color(0, 0, 0), new java.awt.Color(0, 0, 0)));
        jPanel1.setMinimumSize(new java.awt.Dimension(750, 0));
        jPanel1.setPreferredSize(new java.awt.Dimension(675, 363));

        jTable2.setBackground(new java.awt.Color(71, 71, 72));
        jTable2.setForeground(new java.awt.Color(255, 255, 255));
        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "HIP", "TTP", "Quantum", "PRI", "Status", "Suc1", "HISUC1"
            }
        ));
        jTable2.setToolTipText("");
        jTable2.setGridColor(new java.awt.Color(0, 0, 0));
        jTable2.setName(""); // NOI18N
        jScrollPane2.setViewportView(jTable2);

        jTable3.setBackground(new java.awt.Color(71, 71, 72));
        jTable3.setForeground(new java.awt.Color(255, 255, 255));
        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "TTSUC1", "SUC2", "HISUC2", "TTSUC2", "HIBS", "TTBS", "HILS", "TTLS"
            }
        ));
        jTable3.setGridColor(new java.awt.Color(0, 0, 0));
        jScrollPane3.setViewportView(jTable3);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 670, Short.MAX_VALUE)
                    .addComponent(jScrollPane2))
                .addGap(0, 76, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 151, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 675, 381);

        jPanel2.setBackground(new java.awt.Color(51, 51, 51));
        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(0, 0, 0), new java.awt.Color(0, 0, 0), new java.awt.Color(0, 0, 0), new java.awt.Color(0, 0, 0)));
        jPanel2.setForeground(new java.awt.Color(0, 0, 0));
        jPanel2.setPreferredSize(new java.awt.Dimension(675, 363));

        jButton1.setText("Cargar Tabla");
        jButton1.setBorderPainted(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(548, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jButton1)
                .addContainerGap(367, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel2);
        jPanel2.setBounds(0, 384, 675, 420);

        jPanel3.setBackground(new java.awt.Color(51, 51, 51));
        jPanel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(0, 0, 0), new java.awt.Color(0, 0, 0), new java.awt.Color(0, 0, 0), new java.awt.Color(0, 0, 0)));
        jPanel3.setPreferredSize(new java.awt.Dimension(675, 363));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 816, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 377, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel3);
        jPanel3.setBounds(680, 0, 820, 381);

        jPanel4.setBackground(new java.awt.Color(51, 51, 51));
        jPanel4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(0, 0, 0), new java.awt.Color(0, 0, 0), new java.awt.Color(0, 0, 0), new java.awt.Color(0, 0, 0)));
        jPanel4.setPreferredSize(new java.awt.Dimension(675, 363));

        Empezar.setText("  Empezar   ");
        Empezar.setToolTipText("");
        Empezar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                EmpezarMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Empezar)
                .addContainerGap(695, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(Empezar)
                .addContainerGap(367, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel4);
        jPanel4.setBounds(680, 384, 820, 420);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        DefaultTableModel modelo1 = (DefaultTableModel) jTable2.getModel();
        DefaultTableModel modelo2 = (DefaultTableModel) jTable3.getModel();

        modelo1.setNumRows(0);
        modelo2.setNumRows(0);
        listos.clean();

        for (int i = 0; i < 5; i++) {
            String[] dat1 = new String[8];
            String[] dat2 = new String[8];

            listos.add();
            String[] tmp = listos.get(i).getData();

            for (int j = 0; j < 8; j++) {
                dat1[j] = tmp[j];
                dat2[j] = tmp[j + 8];
            }

            modelo1.addRow(dat1);
            modelo2.addRow(dat2);
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void EmpezarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_EmpezarMouseClicked
        passProsBlock();
            blockListo();
    }//GEN-LAST:event_EmpezarMouseClicked

    @Override
    public void run() {
        Thread ct = Thread.currentThread();
        while (ct == hilo) {
            if (quantum == 5) {
                quantum = 0;
            } else {
                quantum++;
            }
            System.out.println(quantum);
            calculateHour();
            labelHour.setText(hour + ":" + minuts + ":" + seconds + " " + turno);

            try {
                Thread.sleep(1000);
                if (block20.get(0) != null) {
                    block20.get(0).ttsuc1--;
                }
                if (block30.get(0) != null) {
                    block30.get(0).ttsuc1--;
                }                                            //FALTA DECREMENTAR EL TTSUC2
                if (block40.get(0) != null) {        //CONDICIONES PARA VER SI HAY PROCESOS EN LA POSICIÓN 0 DE CADA COLA DE BLOQUEADOS Y QUE EMPIECE A DISMINUIR TTSUC
                    block40.get(0).ttsuc1--;     
                }
                if (block50.get(0) != null) {
                    block50.get(0).ttsuc1--;
                }
            } catch (InterruptedException e) {
            }
        }
    }

    private void initComponents2() {
        JTableHeader header2 = jTable2.getTableHeader();
        header2.setForeground(Color.black);
        header2.setFont(new java.awt.Font("Dialog", Font.BOLD, 15));
        header2.setBackground(Color.black);

        JTableHeader header3 = jTable3.getTableHeader();
        header3.setForeground(Color.black);
        header3.setFont(new java.awt.Font("Dialog", Font.BOLD, 15));

        jPanel6.setSize(195, 32);
    }

    public static void main(String args[]) {

        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Design.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Design.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Design.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Design.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Design().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Empezar;
    private javax.swing.JButton jButton1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JLabel labelHour;
    // End of variables declaration//GEN-END:variables

    private Cola listos = new Cola();
    private Cola block20 = new Cola();
    private Cola terminado = new Cola();
    private Cola block30 = new Cola();
    private Cola block40 = new Cola();
    private Cola block50 = new Cola();
    private Cola nuevos = new Cola();

    private Proceso procesador = new Proceso();
    
    public void newListos(){
                                                                    // AQUI VOY A HACER EL METODO DE PASAR DE NUEVOS A LISTOS JIJIJI
    }

    private void passProsBlock() {
        procesador = listos.delete(listos.get(0).getID());           //PASAR EL PROCESO 0 DE LISTOS A PROCESADOR
        int TTP = Integer.parseInt(procesador.getTTP());

        if (TTP != 0 && quantum != 5) {                                     //PARA QUE SE VAYA DISMINUYENDO TTP MIENTRAS AÚN NO ACABEN LOS 5 SEGUNDOS
            procesador.setTTP(Integer.toString(TTP--));
        } else if (TTP <= 0 && procesador.getHISUC1().equals(labelHour) && !procesador.tSuc1) {
            if (procesador.suc1 == 20) {
                block20.addP(listos.delete(procesador.getID()));
                quantum = 0;
            } else if (procesador.suc1 == 30) {                                       //LAS CONDICIONES QUE ME DIJISTE ANOCHE PARA BLOQUEARLOS
                block30.addP(listos.delete(procesador.getID()));               //SE BLOQUEA SI SE LLEGA LA HORA DEL SUCESO1 Y NO HA OCURRIDO
                quantum = 0;
            } else if (procesador.suc1 == 40) {
                block40.addP(listos.delete(procesador.getID()));
                quantum = 0;
            } else if (procesador.suc1 == 50) {
                block50.addP(listos.delete(procesador.getID()));
                quantum = 0;
            }

        } else if (TTP <= 0 && procesador.getHISUC2().equals(labelHour) && procesador.tSuc1 && !procesador.tSuc2) {
            if (procesador.suc1 == 20) {
                block20.addP(listos.delete(procesador.getID()));
                quantum = 0;
            } else if (procesador.suc1 == 30) {
                block30.addP(listos.delete(procesador.getID()));
                quantum = 0;                                                                         //LAS CONDICIONES QUE ME DIJISTE ANOCHE PARA BLOQUEARLOS
            } else if (procesador.suc1 == 40) {                                               //AQUÍ SE BLOQUEA SI SE DA LA HORA DEL SUCESO 2 Y EL SUCESO 1 YA OCURRIÓ
                block40.addP(listos.delete(procesador.getID()));
                quantum = 0;
            } else if (procesador.suc1 == 50) {
                block50.addP(listos.delete(procesador.getID()));
                quantum = 0;

            }
        } else if (quantum == 5) {
            listos.addP(listos.delete(procesador.getID()));                     //SE MANDA A LISTOS DE NUEVO CUANDO SE ACABA EL QUANTUM
            quantum = 0;
        } else {
            terminado.addP(listos.delete(procesador.getID()));
            procesador = listos.delete(listos.get(0).getID());                 //SI EL SUCESO YA TERMINÓ (NO ENTRÓ EN NINGUNA DE LAS CONDICIONES ANTERIORES SE MANDA A
            TTP = Integer.parseInt(procesador.getTTP());                    //TERMINADOS
            quantum = 0;
        }
    }

    private void blockListo() {                                                             //MANDAR DE BLOQUEADO A LISTO
        if (!block20.get(0).tSuc1 && !block20.get(0).tSuc2) {           
            if (block20.get(0).ttsuc1 == 0) {                                               
                listos.addP(block20.delete(block20.get(0).getID()));            //SI NO HA OCURRIDO NINGUNO DE LOS SUC Y EL TTSUC1 ES = 0 SE MANDA A LISTOS Y SE CAMBIA 
                block20.get(0).tSuc1 = true;                                            //LA BANDERA DE SUC1

            } else if (block20.get(0).tSuc1 && !block20.get(0).tSuc2) {
                if (block20.get(0).ttsuc2 == 0) {                                       //SI YA OCURRIO EL  SUC1 Y EL TTSUC2 ES = 0 SE MANDA A LISTOS Y SE CAMBIA 
                block20.get(0).tSuc1 = true;                                            //LA BANDERA DE SUC2
                    listos.addP(block20.delete(block20.get(0).getID()));
                    block20.get(0).tSuc2 = true;
                }
            }
        }
        if (!block30.get(0).tSuc1 && !block30.get(0).tSuc2) {
            if (block30.get(0).ttsuc1 == 0) {
                listos.addP(block30.delete(block30.get(0).getID()));          //LO MISMO QUE EN EL PRIMER IF PERO PARA LOS BLOQUEADOS 30
                block30.get(0).tSuc1 = true;
            }
        } else if (block30.get(0).tSuc1 && !block30.get(0).tSuc2) {
            if (block30.get(0).ttsuc2 == 0) {
                listos.addP(block30.delete(block30.get(0).getID()));
                block30.get(0).tSuc2 = true;
            }
        }

        if (!block40.get(0).tSuc1 && !block40.get(0).tSuc2) {
            if (block40.get(0).ttsuc1 == 0) {
                listos.addP(block40.delete(block40.get(0).getID()));
                block40.get(0).tSuc1 = true;                                             //LO MISMO QUE EN EL PRIMER IF PERO PARA LOS BLOQUEADOS 40
            }
        } else if (block40.get(0).tSuc1 && !block40.get(0).tSuc2) {
            if (block40.get(0).ttsuc2 == 0) {
                listos.addP(block40.delete(block40.get(0).getID()));
                block40.get(0).tSuc2 = true;
            }
        }
        if (!block50.get(0).tSuc1 && !block50.get(0).tSuc2) {
            if (block50.get(0).ttsuc1 == 0) {
                listos.addP(block50.delete(block50.get(0).getID()));
                block50.get(0).tSuc1 = true;
            }                                                                                        //LO MISMO QUE EN EL PRIMER IF PERO PARA LOS BLOQUEADOS 50
        } else if (block50.get(0).tSuc1 && !block50.get(0).tSuc2) {
            if (block50.get(0).ttsuc2 == 0) {
                listos.addP(block50.delete(block50.get(0).getID()));
                block50.get(0).tSuc2 = true;
            }
        }
    }

}

